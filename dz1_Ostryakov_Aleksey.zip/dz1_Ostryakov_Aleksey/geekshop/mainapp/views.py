from django.shortcuts import render


def main(request):
    return render(request, 'mainapp/index.html')


def contact(request):
    return render(request, 'mainapp/contact.html')


def product_details(request):
    return render(request, 'mainapp/product_details.html')


def products(request):
    return render(request, 'mainapp/products.html')
